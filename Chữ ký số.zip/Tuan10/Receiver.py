# receiver.py
import socket
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

def recv_exact(conn, n):
    """Nhận chính xác n byte từ socket"""
    data = b""
    while len(data) < n:
        packet = conn.recv(n - len(data))
        if not packet:
            raise ConnectionError("Kết nối bị ngắt khi đang nhận dữ liệu.")
        data += packet
    return data

# Load khóa công khai
try:
    with open("public_key.pem", "rb") as f:
        public_key = serialization.load_pem_public_key(f.read())
except Exception as e:
    print("Không thể load khóa công khai:", e)
    exit(1)

# Mở socket và chờ kết nối
with socket.socket() as s:
    s.bind(("0.0.0.0", 3456))
    s.listen(1)
    print("Đang chờ kết nối...")

    conn, addr = s.accept()
    print("Đã kết nối từ:", addr)

    with conn:
        try:
            name_len = int.from_bytes(recv_exact(conn, 4), 'big')
            filename = recv_exact(conn, name_len).decode()

            data_len = int.from_bytes(recv_exact(conn, 8), 'big')
            data = recv_exact(conn, data_len)

            sig_len = int.from_bytes(recv_exact(conn, 4), 'big')
            signature = recv_exact(conn, sig_len)

            # Xác minh chữ ký
            public_key.verify(
                signature,
                data,
                padding.PKCS1v15(),
                hashes.SHA256()
            )
            print("✅ Chữ ký hợp lệ. Lưu file.")

            with open(f"received_{filename}", "wb") as f:
                f.write(data)
            print(f"✅ File đã được lưu thành 'received_{filename}'")

        except Exception as e:
            print("❌ Xác minh thất bại hoặc lỗi khi nhận dữ liệu:", e)
