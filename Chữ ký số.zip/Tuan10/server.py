from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os
import base64
from typing import List

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

files = []  # Giả lập database lưu trữ file và thông tin chữ ký


class FileInfo(BaseModel):
    id: int
    filename: str
class SignatureInfo(BaseModel):
    signature: str
    publicKey: str
    filename: str


@app.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    signature: str = Form(...),
    publicKey: str = Form(...),
    filename: str = Form(...)
):
    file_id = len(files) + 1
    file_path = os.path.join(UPLOAD_DIR, f"{file_id}_{file.filename}")
    with open(file_path, "wb") as f:
        content = await file.read()
        f.write(content)

    files.append({
        "id": file_id,
        "filename": filename,
        "path": file_path,
        "signature": signature,
        "publicKey": publicKey
    })
    return {"message": "Tải lên thành công", "id": file_id}


@app.get("/files", response_model=List[FileInfo])
def list_files():
    return [{"id": f["id"], "filename": f["filename"]} for f in files]


@app.get("/files/{file_id}")
def get_file(file_id: int):
    file = next((f for f in files if f["id"] == file_id), None)
    if not file:
        raise HTTPException(status_code=404, detail="Không tìm thấy file")
    return FileResponse(file["path"], filename=file["filename"])


@app.get("/signature/{file_id}", response_model=SignatureInfo)
def get_signature(file_id: int):
    file = next((f for f in files if f["id"] == file_id), None)
    if not file:
        raise HTTPException(status_code=404, detail="Không tìm thấy file")
    return SignatureInfo(signature=file["signature"], publicKey=file["publicKey"], filename=file["filename"])


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="0.0.0.0", port=8000, reload=True)
